# Development reranker comparison

Eight exposed development questions. Forty-candidate depth was selected after observing development ranks. An annotated chunk reaching top five does not prove complete evidence or reliable answers. Exact-cosine candidate selection is distinct from the original Chroma query. No answer generation or held-out evaluation performed.

Raw relevance logits, not factual-support probabilities.

| Case | Annotated chunk | Original five | In cosine forty | Rerank position | Selected five |
|---|---|---|---|---:|---|
| calibration_01 | doc_d55e1b4cf49d694cbaac_p0_c0 | False | True | 3 | True |
| calibration_02 | doc_9f26104ace24902c0800_p0_c3 | True | True | 1 | True |
| calibration_03 | doc_e94742212cb6e9b2f35c_p0_c35 | True | True | 1 | True |
| calibration_03 | doc_e94742212cb6e9b2f35c_p0_c36 | True | True | 2 | True |
| calibration_04 | doc_5843af9345b8b68595b9_p0_c1 | False | True | 1 | True |
| calibration_05 | doc_fc173dce3e92f6ada246_p0_c6 | False | True | 4 | True |
| calibration_05 | doc_fc173dce3e92f6ada246_p0_c7 | False | True | 1 | True |
| calibration_07 | doc_e94742212cb6e9b2f35c_p0_c35 | True | True | 1 | True |
| calibration_08 | doc_9f26104ace24902c0800_p0_c0 | False | True | 4 | True |
| calibration_08 | doc_9f26104ace24902c0800_p0_c6 | True | True | 6 | False |
| calibration_08 | doc_9f26104ace24902c0800_p0_c3 | True | True | 1 | True |
| calibration_08 | doc_9f26104ace24902c0800_p0_c7 | True | True | 5 | True |
