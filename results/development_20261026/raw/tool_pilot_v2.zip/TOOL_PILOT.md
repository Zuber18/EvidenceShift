# Tool-assisted development pilot

Sixteen exposed development inputs. One answer per input; at most two arithmetic planner calls overall. Non-tool requests match the baseline exactly. Prior reranked baseline reused across runs. Prompt and tool pipeline change together, so improvement cannot be attributed to a single component. No final factual certification, training or held-out test.

Reserved calls: 17/18. No automatic semantic accuracy score.

## calibration_01 · canonical

Status: candidate_unverified

The Artemis I mission launched on Nov. 16, 2022 [doc_d55e1b4cf49d694cbaac_p0_c0].

## calibration_01 · reversed

Status: candidate_unverified

The Artemis I mission launched on Nov. 16, 2022 [doc_d55e1b4cf49d694cbaac_p0_c0].

## calibration_02 · reversed

Status: candidate_unverified

The guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used [doc_9f26104ace24902c0800_p0_c3].

## calibration_02 · canonical

Status: candidate_unverified

The guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used [doc_9f26104ace24902c0800_p0_c3].

## calibration_03 · canonical

Status: candidate_unverified

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default value for L is evaluated only once, and it is a mutable object (like a list). This means that the same list is reused across function calls, leading to the accumulation of values [doc_e94742212cb6e9b2f35c_p0_c35]. The L=None alternative avoids sharing the default list by checking if L is None and initializing a new list if it is, thus ensuring that each function call has its own separate list [doc_e94742212cb6e9b2f35c_p0_c36].

## calibration_03 · reversed

Status: candidate_unverified

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default list is evaluated only once and shared between subsequent calls [doc_e94742212cb6e9b2f35c_p0_c35]. The L=None alternative avoids sharing the default list by checking if L is None and initializing it to a new list if it is, thus ensuring each call has its own list [doc_e94742212cb6e9b2f35c_p0_c36].

## calibration_04 · reversed

Status: tool_selection_failed_preserved

(No candidate answer recorded.)

## calibration_04 · canonical

Status: candidate_unverified

The self-reported reading-time estimate is 4.15 hours/week higher than the logged estimate [doc_5843af9345b8b68595b9_p0_c1]. The units are hours/week.

## calibration_05 · canonical

Status: candidate_unverified

The paper's reported 64% moderate-to-high heat-risk result refers to 293 prefecture-level cities in China, not cities worldwide [doc_fc173dce3e92f6ada246_p0_c6]. The supplied evidence does not answer whether this result can be described as 64% of cities worldwide.

## calibration_05 · reversed

Status: candidate_unverified

The paper's reported 64% moderate-to-high heat-risk result refers to 64.16% of the 293 prefecture-level cities in China [doc_fc173dce3e92f6ada246_p0_c60]. The result cannot be described as 64% of cities worldwide, as the study specifically analyzed cities in China [doc_fc173dce3e92f6ada246_p0_c40].

## calibration_06 · reversed

Status: candidate_unverified

The supplied evidence does not answer this question.

## calibration_06 · canonical

Status: candidate_unverified

The supplied evidence does not answer this question.

## calibration_07 · canonical

Status: candidate_unverified

The first call `print(f(1))` outputs `[1]` because the default list is used and appended with `1` [doc_e94742212cb6e9b2f35c_p0_c35]. The second call `print(f(2, []))` outputs `[2]` because an explicit list is provided, resetting the list used [doc_e94742212cb6e9b2f35c_p0_c35]. The third call `print(f(3))` outputs `[1, 3]` because it uses the shared default list, which already contains `1` from the first call [doc_e94742212cb6e9b2f35c_p0_c35]. The middle call does not reset the list used by the final call because the explicit list is provided, and the default list remains unchanged for subsequent calls [doc_e94742212cb6e9b2f35c_p0_c35].

## calibration_07 · reversed

Status: blocked_by_check

The first call, `print(f(1))`, outputs `[1]` because the default list is used and appended with `1` [doc_e94742212cb6e9b2f35c_p0_c35]. The second call, `print(f(2, []))`, outputs `[2]` because an explicit list is provided, which does not share the default list [doc_e94742212cb6e9b2f35c_p0_c35]. The third call, `print(f(3))`, outputs `[1, 3]` because it uses the shared default list, which already contains `1` from the first call [doc_e94742212cb6e9b2f35c_p0_c35]. The middle call does not reset the list used by the final call because it explicitly provides a new list, while the final call reuses the shared default list [doc_e94742212cb6e9b2f35c_p0_c35].

## calibration_08 · reversed

Status: candidate_unverified

The GOV.UK guide does not support the first rule of removing every specialist term even when a user needs it. The guide states that specialist terms can be used if needed, and they should be explained the first time they are used [doc_9f26104ace24902c0800_p0_c3]. The guide also does not support the second rule of rewriting every passive sentence even when the passive wording is more user-centred. The guide acknowledges that passive voice can be appropriate when the outcome is more important than the agent of the action or when the writing is more user-centred [doc_9f26104ace24902c0800_p0_c7]. A revision policy that preserves the guide's general aims and both exceptions could include: use specialist terms when necessary and explain them the first time they are used, and use passive voice when the outcome is more important than the agent of the action or when the writing is more user-centred.

## calibration_08 · canonical

Status: candidate_unverified

The GOV.UK guide does not support the editor's rules. The guide states that specialist language can be used if needed, and it should be explained the first time it is used [doc_9f26104ace24902c0800_p0_c3]. Additionally, the guide acknowledges that passive voice can be appropriate when the outcome is more important than the agent of the action or when the writing is more user-centred [doc_9f26104ace24902c0800_p0_c7]. A revision policy that preserves the guide's general aims and both exceptions could include: retaining specialist terms when necessary and explaining them upon first use, and using passive voice when the outcome is more important than the agent or when the writing is more user-centred.
