# Source quantity candidates

Exact ordinary decimal/unit extraction only. No role, direction, section or semantic entailment certification; no conversion or inferred units. Same candidate set under reversal does not prove order-invariant model selection. Candidate eligibility does not establish a correct answer.

## calibration_04

Using the weekly means reported in the abstract, how much higher is the self-reported reading-time estimate than the logged estimate? State the units.

| ID | Value | Source unit | Passage |
|---|---|---|---|
| q_12d124249224f915e279 | 6.26 | hours/week | doc_5843af9345b8b68595b9_p0_c1 |
| q_c1320e00bce7728f7068 | 2.11 | hours/week | doc_5843af9345b8b68595b9_p0_c1 |
| q_d647187595ba6e47926e | 4 | hours per week | doc_5843af9345b8b68595b9_p0_c35 |

Eligible candidates: 3; order-invariant set: True.
