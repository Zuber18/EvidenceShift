# Candidate pool diagnostic

Development diagnostic only. Exact cosine ranks are exhaustive within each declared source scope; Chroma pools are separately queried approximate-index outputs from a rebuilt temporary index. Any baseline drift is explicitly flagged. More annotation overlap is not a semantic accuracy score. Pool size is candidate retrieval depth, not an instruction to send 20 passages to the generator.

Answer-generation calls: 0.

| Case | Annotation-overlapping chunk | Exact cosine rank | Present in Chroma pools |
|---|---|---:|---|
| calibration_01 | doc_d55e1b4cf49d694cbaac_p0_c0 | 17 | 20 |
| calibration_02 | doc_9f26104ace24902c0800_p0_c3 | 2 | 5, 10, 20 |
| calibration_03 | doc_e94742212cb6e9b2f35c_p0_c35 | 1 | 5, 10, 20 |
| calibration_03 | doc_e94742212cb6e9b2f35c_p0_c36 | 2 | 5, 10, 20 |
| calibration_04 | doc_5843af9345b8b68595b9_p0_c1 | 7 | 10, 20 |
| calibration_05 | doc_fc173dce3e92f6ada246_p0_c6 | 28 | none |
| calibration_05 | doc_fc173dce3e92f6ada246_p0_c7 | 24 | none |
| calibration_07 | doc_e94742212cb6e9b2f35c_p0_c35 | 1 | 5, 10, 20 |
| calibration_08 | doc_9f26104ace24902c0800_p0_c0 | 7 | 10, 20 |
| calibration_08 | doc_9f26104ace24902c0800_p0_c6 | 5 | 5, 10, 20 |
| calibration_08 | doc_9f26104ace24902c0800_p0_c3 | 2 | 5, 10, 20 |
| calibration_08 | doc_9f26104ace24902c0800_p0_c7 | 1 | 5, 10, 20 |

All rebuilt top-five orders match original: True
