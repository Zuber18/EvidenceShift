# Source quantity selection pilot

One exposed development question in two orders, one model. Candidate selection and its prompt change together. A source-anchored arithmetic result is conditional on semantic roles and direction. No held-out evaluation or general accuracy estimate.

Recorded attempts: 4/4.

## reversed

candidate_unverified

The self-reported reading-time estimate is 4.15 hours/week higher than the logged estimate [doc_5843af9345b8b68595b9_p0_c1]. The units are hours/week.

## canonical

candidate_unverified

The self-reported reading-time estimate is 4.15 hours/week higher than the logged estimate [doc_5843af9345b8b68595b9_p0_c1]. The units are hours/week.
