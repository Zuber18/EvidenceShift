# Qwen 8B original-versus-reranked comparison

Exposed development comparison; not a held-out accuracy estimate. One attempt per condition, failures retained without automatic retries.

Canonical is original retrieval order in the original arm and reranker order in the reranked arm. Reversed flips only that arm's saved five passages.

Reserved attempts: 32/32. No automatic semantic score.

## calibration_01 · original · canonical

Status: output_recorded

The Artemis I mission launched on Nov. 16, 2022 [doc_d55e1b4cf49d694cbaac_p0_c28].

## calibration_01 · original · reversed

Status: output_recorded

The Artemis I mission launched on Nov. 16, 2022, according to passage [doc_d55e1b4cf49d694cbaac_p0_c3].

## calibration_01 · reranked · canonical

Status: output_recorded

The Artemis I mission launched on Nov. 16, 2022 [doc_d55e1b4cf49d694cbaac_p0_c0].

## calibration_01 · reranked · reversed

Status: output_recorded

The Artemis I mission launched on Nov. 16, 2022 [doc_d55e1b4cf49d694cbaac_p0_c0].

## calibration_02 · original · reversed

Status: output_recorded

The guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used [doc_9f26104ace24902c0800_p0_c3].

## calibration_02 · reranked · canonical

Status: output_recorded

The guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used [doc_9f26104ace24902c0800_p0_c3].

## calibration_02 · reranked · reversed

Status: output_recorded

The guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used [doc_9f26104ace24902c0800_p0_c3].

## calibration_02 · original · canonical

Status: output_recorded

The guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used [doc_9f26104ace24902c0800_p0_c3].

## calibration_03 · reranked · canonical

Status: output_recorded

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default value for L is evaluated only once, and it is a mutable object (like a list). This means that the same list is reused across function calls, leading to the accumulation of values [doc_e94742212cb6e9b2f35c_p0_c35]. The L=None alternative avoids sharing the default list by checking if L is None and initializing a new list if it is, thus ensuring that each function call has its own separate list [doc_e94742212cb6e9b2f35c_p0_c36].

## calibration_03 · reranked · reversed

Status: output_recorded

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default list is evaluated only once and shared between subsequent calls [doc_e94742212cb6e9b2f35c_p0_c35]. The L=None alternative avoids sharing the default list by checking if L is None and initializing it to a new list if it is, thus ensuring each call has its own list [doc_e94742212cb6e9b2f35c_p0_c36].

## calibration_03 · original · canonical

Status: output_recorded

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default list is evaluated only once and shared between subsequent calls [doc_e94742212cb6e9b2f35c_p0_c35]. The L=None alternative avoids sharing the default list by checking if L is None and initializing a new list if it is, thus ensuring each call has its own list [doc_e94742212cb6e9b2f35c_p0_c36].

## calibration_03 · original · reversed

Status: output_recorded

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default list is mutable and shared between calls [doc_e94742212cb6e9b2f35c_p0_c35]. The L=None alternative avoids sharing the default list by checking if L is None and initializing it to a new list if it is, thus ensuring each call has its own list [doc_e94742212cb6e9b2f35c_p0_c36].

## calibration_04 · reranked · reversed

Status: output_recorded

The self-reported reading-time estimate is 4 hours higher than the logged estimate per week [doc_5843af9345b8b68595b9_p0_c35].

## calibration_04 · original · canonical

Status: output_recorded

The self-reported reading-time estimate is 4 hours higher than the logged estimate [doc_5843af9345b8b68595b9_p0_c50]. The units are hours.

## calibration_04 · original · reversed

Status: output_recorded

The self-reported reading-time estimate is 4.15 hours higher than the logged estimate, as the self-reported measure overestimates reading time by an average of four hours [doc_5843af9345b8b68595b9_p0_c50]. The units are hours.

## calibration_04 · reranked · canonical

Status: output_recorded

The self-reported reading-time estimate is 4 hours higher than the logged estimate per week [doc_5843af9345b8b68595b9_p0_c35].

## calibration_05 · original · canonical

Status: output_recorded

The supplied evidence does not answer this question.

## calibration_05 · original · reversed

Status: output_recorded

The supplied evidence does not answer this question.

## calibration_05 · reranked · canonical

Status: output_recorded

The paper's reported 64% moderate-to-high heat-risk result refers to 293 prefecture-level cities in China, not cities worldwide [doc_fc173dce3e92f6ada246_p0_c6]. The supplied evidence does not answer whether this result can be described as 64% of cities worldwide.

## calibration_05 · reranked · reversed

Status: output_recorded

The paper's reported 64% moderate-to-high heat-risk result refers to 64.16% of the 293 prefecture-level cities in China [doc_fc173dce3e92f6ada246_p0_c60]. The result cannot be described as 64% of cities worldwide, as the study specifically analyzed cities in China [doc_fc173dce3e92f6ada246_p0_c40].

## calibration_06 · original · reversed

Status: output_recorded

The supplied evidence does not answer this question.

## calibration_06 · reranked · canonical

Status: output_recorded

The supplied evidence does not answer this question.

## calibration_06 · reranked · reversed

Status: output_recorded

The supplied evidence does not answer this question.

## calibration_06 · original · canonical

Status: output_recorded

The supplied evidence does not answer this question.

## calibration_07 · reranked · canonical

Status: output_recorded

The call `print(f(1))` will print `[1]`, `print(f(2, []))` will print `[2]`, and `print(f(3))` will print `[1, 2, 3]`. The middle call does not reset the list used by the final call because the default list is created once and reused for subsequent calls unless explicitly reset [doc_e94742212cb6e9b2f35c_p0_c35]. The final call appends to the same list, hence the output includes previous values.

## calibration_07 · reranked · reversed

Status: output_recorded

The call `print(f(1))` outputs `[1]`, `print(f(2, []))` outputs `[2]`, and `print(f(3))` outputs `[1, 2, 3]`. The middle call does not reset the list used by the final call because the default list is created once and reused unless explicitly provided [doc_e94742212cb6e9b2f35c_p0_c35]. The final call uses the same default list as the first call, hence the list grows with each subsequent call.

## calibration_07 · original · canonical

Status: output_recorded

The call `print(f(1))` will output `[1]`, `print(f(2, []))` will output `[2]`, and `print(f(3))` will output `[1, 2, 3]` [doc_e94742212cb6e9b2f35c_p0_c35]. The middle call does not reset the list used by the final call because the default value for the parameter `L` is evaluated only once, and it is shared between all calls unless explicitly reset [doc_e94742212cb6e9b2f35c_p0_c35].

## calibration_07 · original · reversed

Status: output_recorded

The call `print(f(1))` outputs `[1]`, `print(f(2, []))` outputs `[2]`, and `print(f(3))` outputs `[3]`. The middle call does not reset the list used by the final call because the default list `L=[]` is evaluated only once when the function is defined, and the final call uses a new local symbol table, which does not affect the default list used in the middle call [doc_e94742212cb6e9b2f35c_p0_c35].

## calibration_08 · reranked · reversed

Status: output_recorded

The GOV.UK guide does not support the first rule of removing every specialist term even when a user needs it. The guide states that specialist terms can be used if needed, and they should be explained the first time they are used [doc_9f26104ace24902c0800_p0_c3]. The guide also does not support the second rule of rewriting every passive sentence even when the passive wording is more user-centred. The guide acknowledges that passive voice can be appropriate when the outcome is more important than the agent of the action or when the writing is more user-centred [doc_9f26104ace24902c0800_p0_c7]. A revision policy that preserves the guide's general aims and both exceptions could include: use specialist terms when necessary and explain them the first time they are used, and use passive voice when the outcome is more important than the agent of the action or when the writing is more user-centred.

## calibration_08 · original · canonical

Status: output_recorded

The GOV.UK guide does not support the removal of every specialist term, as it states that specialist language can be used if needed, provided it is explained in plain English the first time it is used [doc_9f26104ace24902c0800_p0_c3]. Similarly, the guide does not support rewriting every passive sentence, as it acknowledges that passive voice can be appropriate when the outcome is more important than the agent of the action or when the writing is more user-centred [doc_9f26104ace24902c0800_p0_c7]. A revision policy that preserves the guide's general aims and both exceptions could include: retaining specialist terms when necessary and explaining them, and using passive voice when the outcome is more important than the agent of the action or when the writing is more user-centred.

## calibration_08 · original · reversed

Status: output_recorded

The GOV.UK guide does not support the first rule of removing every specialist term even when a user needs it to complete a task. The guide states that specialist language can be used if needed and should be explained the first time they are used [doc_9f26104ace24902c0800_p0_c3]. 

The guide does support the second rule of rewriting every passive sentence even when the passive wording is more user-centred. The guide suggests using the active voice as it is more direct and puts the focus on the user and the action they need to take [doc_9f26104ace24902c0800_p0_c1].

A revision policy that preserves the guide's general aims and both exceptions could be: use specialist terms when necessary and explain them the first time they are used, and use the active voice unless the passive voice is more user-centred.

## calibration_08 · reranked · canonical

Status: output_recorded

The GOV.UK guide does not support the editor's rules. The guide states that specialist language can be used if needed, and it should be explained the first time it is used [doc_9f26104ace24902c0800_p0_c3]. Additionally, the guide acknowledges that passive voice can be appropriate when the outcome is more important than the agent of the action or when the writing is more user-centred [doc_9f26104ace24902c0800_p0_c7]. A revision policy that preserves the guide's general aims and both exceptions could include: retaining specialist terms when necessary and explaining them upon first use, and using passive voice when the outcome is more important than the agent or when the writing is more user-centred.
