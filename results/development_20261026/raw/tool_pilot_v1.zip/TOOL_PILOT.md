# Tool-assisted development pilot

Sixteen exposed development inputs. Up to two calls per input. Prior reranked baseline reused across runs. Prompt and tool pipeline change together, so improvement cannot be attributed to a single component. No final factual certification, training or held-out test.

Reserved calls: 32/32. No automatic semantic accuracy score.

## calibration_01 · canonical

Status: blocked_by_check

The Artemis I mission launched on Nov. 16, 2022, according to the mission overview in passage "doc_d55e1b4cf49d694cbaac_p0_c0".

## calibration_01 · reversed

Status: blocked_by_check

The Artemis I mission launched on Nov. 16, 2022, according to the mission overview. (passage: doc_d55e1b4cf49d694cbaac_p0_c0)

## calibration_02 · reversed

Status: blocked_by_check

The guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used. The passage states: "Use specialist language if needed. Where you need to use specialist terms, you can. They’re not always jargon. You just need to explain what they mean the first time you use them." (doc_9f26104ace24902c0800_p0_c3)

## calibration_02 · canonical

Status: blocked_by_check

No, the guidance does not prohibit all specialist terms. If specialist terms are needed, the writer must explain what they mean the first time they are used. Passage ID: doc_9f26104ace24902c0800_p0_c3.

## calibration_03 · canonical

Status: blocked_by_check

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default value for L is evaluated only once, and it is a mutable object (like a list). This means that the same list is reused across function calls, leading to the accumulation of values. The L=None alternative avoids sharing the default list by checking if L is None and initializing a new list if it is, thus ensuring each call has its own separate list. The supplied evidence does not answer this question.

## calibration_03 · reversed

Status: blocked_by_check

When L is omitted, repeated calls to the documented f(a, L=[]) accumulate values because the default list is mutable and evaluated only once, leading to shared state across calls. The L=None alternative avoids sharing the default list by checking if L is None and initializing a new list if it is, thus ensuring each call has its own list. The supplied evidence does not answer this question.

## calibration_04 · reversed

Status: blocked_by_check

The self-reported reading-time estimate is 4.15 hours higher than the logged estimate. Units: hours.

## calibration_04 · canonical

Status: blocked_by_check

The self-reported reading-time estimate is 4.15 hours/week higher than the logged estimate. The units are hours/week.

## calibration_05 · canonical

Status: blocked_by_check

The paper’s reported 64% moderate-to-high heat-risk result cannot be described as 64% of cities worldwide. The result refers to 64% of the 293 prefecture-level cities in China. The actual city sample to which the result refers is 293 cities in China.

## calibration_05 · reversed

Status: blocked_by_check

The paper’s reported 64% moderate-to-high heat-risk result cannot be described as 64% of cities worldwide. The actual city sample to which the result refers is 293 prefecture-level cities in China. The 64% figure refers to these cities, not cities worldwide. The supplied evidence does not answer this question.

## calibration_06 · reversed

Status: candidate_unverified

The supplied evidence does not answer this question.

## calibration_06 · canonical

Status: candidate_unverified

The supplied evidence does not answer this question.

## calibration_07 · canonical

Status: blocked_by_check

print(f(1)) outputs [1] because the default list is shared and appended with 1. print(f(2, [])) outputs [2] because an explicit list is provided, resetting the list for that call. print(f(3)) outputs [1, 3] because the default list is shared again, and 3 is appended to the list that already contains 1 from the first call. The middle call does not reset the list used by the final call because the explicit list provided in the middle call is local to that call and does not affect the shared default list used in the final call. The supplied evidence does not answer this question.

## calibration_07 · reversed

Status: blocked_by_check

print(f(1)) outputs [1] because the default list is used and appended with 1. print(f(2, [])) outputs [2] because an explicit list is provided, resetting the list for that call. print(f(3)) outputs [1, 3] because the default list is reused, and 3 is appended to the list that already contains 1 from the first call. The middle call does not reset the list used by the final call because the explicit list provided in the middle call is not shared with subsequent calls. The final call uses the shared default list, which retains the value from the first call. The middle call uses a separate list, so it does not affect the final call. The supplied evidence does not answer this question.

## calibration_08 · reversed

Status: candidate_unverified

The supplied evidence does not answer this question.

## calibration_08 · canonical

Status: candidate_unverified

The supplied evidence does not answer this question.
