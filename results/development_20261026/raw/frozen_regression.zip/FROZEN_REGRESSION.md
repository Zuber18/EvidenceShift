# Frozen coverage regression

Fixed three-case development regression, two orders, three models. All questions have been exposed during development. The smaller Qwen is the previously probed replacement artifact, not the original thinking-heavy Qwen 4B. Known IDs, valid schemas and required fields do not establish factual correctness or citation entailment. No prompt tuning after this run; report remaining failures. No fine-tuning or reserved-split evaluation.

Recorded attempts: 18/18.

## qwen3:8b / calibration_05 / canonical

candidate_unverified

The reported 64% moderate-to-high heat-risk result cannot be described as a result about cities worldwide. The study specifically refers to cities in China. [doc_fc173dce3e92f6ada246_p0_c7] [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c19]

The actual city sample to which the result refers is 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c7] [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c19]

## qwen3:8b / calibration_05 / reversed

candidate_unverified

The reported 64% moderate-to-high heat-risk result cannot be described as a result about cities worldwide. The study specifically focused on 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c40]

The actual city sample to which the result refers is 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c40]

## qwen3:8b / calibration_06 / reversed

candidate_unverified

The supplied evidence does not answer this question.

## qwen3:8b / calibration_06 / canonical

candidate_unverified

The supplied evidence does not answer this question.

## qwen3:8b / calibration_08 / canonical

candidate_unverified

The proposed blanket rules do not follow from the guide. The guide allows for the use of specialist terms when needed and permits the use of passive voice in certain circumstances. [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c7]

The general aim that the proposed revision policy should preserve is to ensure that GOV.UK content is accessible and understandable to everyone who needs it, including those with limited literacy skills and non-native English speakers. [doc_9f26104ace24902c0800_p0_c0]

The revision policy for specialist terms should allow their use when needed, provided they are explained in plain English the first time they are used. This ensures that users who need the terms to complete a task can understand them. [doc_9f26104ace24902c0800_p0_c3]

The revision policy for passive voice should allow its use when the outcome is more important than the agent of the action or when the writing is more user-centred. This preserves the guide's aim of making content accessible and user-focused. [doc_9f26104ace24902c0800_p0_c7]

## qwen3:8b / calibration_08 / reversed

candidate_unverified

The proposed blanket rules do not follow from the guide. The guide allows for the use of specialist terms when needed and permits passive voice in specific circumstances, such as when the outcome is more important than the agent of the action or when the writing is more user-centred. [doc_9f26104ace24902c0800_p0_c7] [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c1]

The general aim that the proposed revision policy should preserve is to ensure that content is accessible and understandable to everyone who needs it, including those with limited literacy skills and non-native English speakers. [doc_9f26104ace24902c0800_p0_c0] [doc_9f26104ace24902c0800_p0_c1]

The revision policy for specialist terms should allow their use when needed, such as when users require them to complete a task. Specialist terms should be explained in plain English the first time they are used to ensure clarity for all users. [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c2]

The revision policy for passive voice should allow its use in specific circumstances, such as when the outcome is more important than the agent of the action or when the writing is more user-centred. Passive voice should be used judiciously and only when it enhances clarity and user focus. [doc_9f26104ace24902c0800_p0_c7] [doc_9f26104ace24902c0800_p0_c1]

## qwen3:4b-instruct-2507-q4_K_M / calibration_05 / canonical

candidate_unverified

The reported 64% moderate-to-high heat-risk result is stated in the context of 293 prefecture-level cities in China, not worldwide. While the paper discusses global warming and references the IPCC, the specific heat-risk assessment is limited to China. This contradicts any claim of a worldwide scope, as the sample is geographically restricted to China. The use of 'overall' in the text does not extend the scope beyond China, and no evidence supports a worldwide city sample. Thus, describing the result as 'worldwide' would be a misrepresentation. [doc_fc173dce3e92f6ada246_p0_c7] [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c6]

The result refers to 293 prefecture-level cities in China, specifically those analyzed in the study, with higher heat risk concentrated in southern and central China, including parts of Guangxi, Guangdong, Henan, Hebei, and Sichuan. [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c6]

## qwen3:4b-instruct-2507-q4_K_M / calibration_05 / reversed

structure_failed_preserved

(No rendered answer; see saved state/raw output.)

## qwen3:4b-instruct-2507-q4_K_M / calibration_06 / reversed

candidate_unverified

The supplied evidence does not answer this question.

## qwen3:4b-instruct-2507-q4_K_M / calibration_06 / canonical

candidate_unverified

The supplied evidence does not answer this question.

## qwen3:4b-instruct-2507-q4_K_M / calibration_08 / canonical

candidate_unverified

The proposed blanket rules conflict with the guide's principles. While the guide encourages removing complex or vague terms and using active voice for user-centredness, it explicitly allows specialist terms when needed, and acknowledges that passive voice can be appropriate when the outcome is more important than the agent. Thus, removing every specialist term or rewriting every passive sentence without exception contradicts the guide's exceptions and specific conditions. The guide supports using specialist language if necessary, with explanation on first use, and permits passive voice when user-centred outcomes are prioritised. Therefore, the blanket rules do not follow from the guide and instead override its established exceptions. [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c1] [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c7]

The general aim of the GOV.UK clear language guide is to ensure content is accessible and understandable to everyone who needs it, particularly those with limited literacy skills or who do not speak English as their first language. This includes making content clear for both general audiences and specialists, while still allowing for the use of specialist terms when necessary, provided they are explained. The aim is not to eliminate all technical language, but to ensure clarity and usability for all users, regardless of background or expertise. [doc_9f26104ace24902c0800_p0_c0] [doc_9f26104ace24902c0800_p0_c1] [doc_9f26104ace24902c0800_p0_c2]

Specialist terms should be used when necessary, particularly if users need to complete a task that requires familiarity with such terms. For example, a legal term like 'bona vacantia' may be needed for users to understand a process. However, when specialist terms are used, they must be explained in plain English on first occurrence. The guide does not require removing all specialist terms, but ensures that any such terms are clear and accessible. Thus, the revision policy is to retain specialist terms when needed, with a clear explanation provided to ensure understanding by all users. [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c1] [doc_9f26104ace24902c0800_p0_c2]

Passive voice should be used only when the outcome is more important than the agent of the action, or when the writing is more user-centred. For example, 'You’ll be told what you need to do when you apply' is more user-centred than 'The Home Office will tell you what you need to do when you apply'. In such cases, passive voice can be appropriate. However, when the user action or responsibility is central, active voice is preferred. The guide does not require rewriting every passive sentence, and allows exceptions where user-centredness is achieved through passive construction. Therefore, passive voice should be used selectively, not universally. [doc_9f26104ace24902c0800_p0_c7]

## qwen3:4b-instruct-2507-q4_K_M / calibration_08 / reversed

candidate_unverified

The proposed blanket rule to remove every specialist term even when a user needs it to complete a task contradicts the guide, which states that specialist terms can be used if needed, provided they are explained on first use. Similarly, the rule to rewrite every passive sentence even when the passive wording is more user-centred contradicts the guide, which explicitly acknowledges that passive voice can be user-centred in certain cases, such as when the outcome is more important than the agent. Thus, the two blanket rules go against specific exceptions in the guide and do not follow from its principles. The guide allows for specialist terms and passive voice when they serve user needs and are appropriately contextualized. [doc_9f26104ace24902c0800_p0_c7] [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c1] [doc_9f26104ace24902c0800_p0_c3]

The general aim of the GOV.UK clear language guide is to ensure content is accessible and understandable to everyone who needs it, including those with limited literacy skills or who do not speak English as their first language. This includes making content clear for both general and specialist audiences, while still allowing for the use of specialist terms when necessary, provided they are explained clearly on first use. [doc_9f26104ace24902c0800_p0_c0] [doc_9f26104ace24902c0800_p0_c1] [doc_9f26104ace24902c0800_p0_c2]

Specialist terms can be used when necessary for users to complete a task, such as legal or technical terms. However, they must be explained in plain English the first time they are used. For example, a term like 'bona vacantia' should be defined in simple language when introduced. This ensures that users with varying levels of expertise can understand the content. The rule is not to remove all specialist terms, but to use them selectively and transparently with clear explanations. [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c1]

Passive voice should be used when the outcome is more important than the agent of the action, or when the writing is more user-centred. For example, 'You’ll be told what you need to do when you apply' is more user-centred than 'The Home Office will tell you what you need to do when you apply'. However, passive voice should not be used if it obscures responsibility or makes the content less clear. The guide supports passive voice in specific, user-centred contexts but does not require rewriting every passive sentence. Active voice is preferred when it improves clarity and user-centredness. [doc_9f26104ace24902c0800_p0_c7] [doc_9f26104ace24902c0800_p0_c3]

## gemma3:4b / calibration_05 / canonical

candidate_unverified

The reported 64% result refers to 64.16% of China’s 293 prefecture-level cities. [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c19]

The actual city sample to which the result refers is 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c19]

## gemma3:4b / calibration_05 / reversed

candidate_unverified

The reported percentage of 64% can be described as a result about cities worldwide because 64% of the 293 cities examined fell into moderate to high-risk categories. [doc_fc173dce3e92f6ada246_p0_c19] [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c60]

The actual city sample to which the result refers is 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c19] [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c60]

## gemma3:4b / calibration_06 / reversed

candidate_unverified

The guidance does not state a minimum Flesch Reading Ease score that every GOV.UK page must achieve. [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c5] [doc_9f26104ace24902c0800_p0_c8] [doc_9f26104ace24902c0800_p0_c1] [doc_9f26104ace24902c0800_p0_c0]

## gemma3:4b / calibration_06 / canonical

candidate_unverified

The guidance does not state a minimum Flesch Reading Ease score that every GOV.UK page must achieve. [doc_9f26104ace24902c0800_p0_c0] [doc_9f26104ace24902c0800_p0_c1] [doc_9f26104ace24902c0800_p0_c8] [doc_9f26104ace24902c0800_p0_c5] [doc_9f26104ace24902c0800_p0_c2]

## gemma3:4b / calibration_08 / canonical

candidate_unverified

The proposed blanket rules – removing specialist terms and rewriting passive sentences – do not follow from the guide. The guide explicitly states that specialist terms can be used if explained, and that the passive voice can be used when the outcome is more important or when the writing is user-centred. These blanket rules contradict this nuanced approach. [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c2]

The general aim that the proposed revision policy should preserve is to communicate clearly for all users, including those with lower literacy skills and those who may not be native English speakers, while acknowledging that specialist language may be appropriate in certain contexts. [doc_9f26104ace24902c0800_p0_c0] [doc_9f26104ace24902c0800_p0_c1]

The revision policy for specialist terms should allow their use when explained, as outlined in doc_9f26104ace24902c0800_p0_c3. The policy should also include a condition that the term must be explained the first time it is used. There are no exceptions listed in the provided passages. [doc_9f26104ace24902c0800_p0_c3]

The revision policy for passive voice should allow its use when the outcome is more important than the agent of the action, as stated in doc_9f26104ace24902c0800_p0_c2. It should also allow its use when the writing is more user-centred. There are no exceptions listed in the provided passages. [doc_9f26104ace24902c0800_p0_c2]

## gemma3:4b / calibration_08 / reversed

candidate_unverified

The proposed blanket rules – removing all specialist terms and rewriting all passive sentences – do not follow from the guide. The guide explicitly states that the passive voice can be acceptable ‘when the outcome is more important than the agent of the action’ and ‘when the writing is more user-centred’. Removing all specialist terms regardless of context contradicts the guidance to use specialist language when necessary, explaining it the first time, and to consider the user’s preference for plain English. The guide also states that ‘For example, users may need to be familiar with a legal term like ‘bona vacantia’ in order to complete a task. Explain the term in plain English when you first use it.’, indicating that specialist terms can be used if explained. [doc_9f26104ace24902c0800_p0_c7] [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c1]

The general aim that the proposed revision policy should preserve is to communicate clearly and accessibly to all users, including those with low literacy skills, while acknowledging the need for specialist language when appropriate and explaining it clearly. [doc_9f26104ace24902c0800_p0_c0] [doc_9f26104ace24902c0800_p0_c1]

The revision policy for specialist terms should allow their use when necessary, explaining them clearly the first time they appear. The guide states ‘Where you need to use specialist terms, you can. They’re not always jargon. You just need to explain what they mean the first time you use them.’. There are no conditions or exceptions that would justify a blanket removal of specialist terms. [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c1]

The revision policy for passive voice should allow its use when the outcome is more important than the agent of the action, or when the writing is more user-centred. The guide states ‘There are some circumstances when the passive voice can work. These include: when the outcome is more important than the agent of the action – for example, ‘Biometric residence permits have been replaced by eVisas’’. It also states ‘when the writing is more user-centred – for example, ‘You’ll be told what you need to do when you apply’ rather than ‘The Home Office will tell you what you need to do when you apply’’. [doc_9f26104ace24902c0800_p0_c7]
