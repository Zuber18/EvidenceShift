# Evidence coverage development pilot

Three exposed development questions, two passage orders, one model. A single schema-constrained generation per input. Question-only requirements are manually specified for these cases; this is not an automatic question-decomposition benchmark. Schema validity, known IDs and filled slots do not certify claim support, semantic completeness or answerability. No held-out evaluation or training. The pipeline is frozen after this bounded diagnostic; remaining reasoning failures must be reported.

Recorded attempts: 6/6.

## calibration_05 / canonical

candidate_unverified

The reported 64% moderate-to-high heat-risk result cannot be described as a result about cities worldwide. The study specifically refers to cities in China. [doc_fc173dce3e92f6ada246_p0_c7] [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c19]

The actual city sample to which the result refers is 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c7] [doc_fc173dce3e92f6ada246_p0_c40] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c19]

## calibration_05 / reversed

candidate_unverified

The reported 64% moderate-to-high heat-risk result cannot be described as a result about cities worldwide. The study specifically focused on 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c40]

The actual city sample to which the result refers is 293 prefecture-level cities in China. [doc_fc173dce3e92f6ada246_p0_c6] [doc_fc173dce3e92f6ada246_p0_c60] [doc_fc173dce3e92f6ada246_p0_c40]

## calibration_06 / reversed

candidate_unverified

The supplied evidence does not answer this question.

## calibration_06 / canonical

candidate_unverified

The supplied evidence does not answer this question.

## calibration_08 / canonical

candidate_unverified

The proposed blanket rules do not follow from the guide. The guide allows for the use of specialist terms when needed and permits the use of passive voice in certain circumstances. [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c7]

The general aim that the proposed revision policy should preserve is to ensure that GOV.UK content is accessible and understandable to everyone who needs it, including those with limited literacy skills and non-native English speakers. [doc_9f26104ace24902c0800_p0_c0]

The revision policy for specialist terms should allow their use when needed, provided they are explained in plain English the first time they are used. This ensures that users who need the terms to complete a task can understand them. [doc_9f26104ace24902c0800_p0_c3]

The revision policy for passive voice should allow its use when the outcome is more important than the agent of the action or when the writing is more user-centred. This preserves the guide's aim of making content accessible and user-focused. [doc_9f26104ace24902c0800_p0_c7]

## calibration_08 / reversed

candidate_unverified

The proposed blanket rules do not follow from the guide. The guide allows for the use of specialist terms when needed and permits passive voice in specific circumstances, such as when the outcome is more important than the agent of the action or when the writing is more user-centred. [doc_9f26104ace24902c0800_p0_c7] [doc_9f26104ace24902c0800_p0_c2] [doc_9f26104ace24902c0800_p0_c1]

The general aim that the proposed revision policy should preserve is to ensure that content is accessible and understandable to everyone who needs it, including those with limited literacy skills and non-native English speakers. [doc_9f26104ace24902c0800_p0_c0] [doc_9f26104ace24902c0800_p0_c1]

The revision policy for specialist terms should allow their use when needed, such as when users require them to complete a task. Specialist terms should be explained in plain English the first time they are used to ensure clarity for all users. [doc_9f26104ace24902c0800_p0_c3] [doc_9f26104ace24902c0800_p0_c2]

The revision policy for passive voice should allow its use in specific circumstances, such as when the outcome is more important than the agent of the action or when the writing is more user-centred. Passive voice should be used judiciously and only when it enhances clarity and user focus. [doc_9f26104ace24902c0800_p0_c7] [doc_9f26104ace24902c0800_p0_c1]
