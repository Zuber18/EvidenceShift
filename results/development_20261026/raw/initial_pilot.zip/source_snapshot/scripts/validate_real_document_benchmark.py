"""Check local benchmark structure and source provenance without model calls.

Passing this validator establishes file/annotation consistency, not factual
correctness. Readiness also requires complete gold review and frozen artefacts.
"""
import argparse
from collections import Counter, defaultdict
from decimal import Decimal, ROUND_CEILING
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT / 'evaluation/benchmarks/real_documents_v1'


def check_freeze(base):
    """Verify the sealed source/gold bytes; a status word is not a freeze."""
    path=base/'freeze_manifest.json'
    if not path.exists(): return False, ['Freeze manifest is missing.']
    manifest=json.loads(path.read_text()); errors=[]
    files=manifest.get('files',{})
    required={'cases.json','protocol.json','allocation.json','sources.proposed.json',
              'failure_rubric.json','case_reviews.json','absence_review.json','source_qa_review.json'}
    source_inventory=json.loads((base/'sources.proposed.json').read_text())['sources']
    for source in source_inventory:
        prefix=f"source_snapshots/{source['id']}/"
        required.update(prefix+n for n in ['raw.html','capture.json','body.txt','extraction.json','NOTICE.md'])
        if source['document_type']=='scientific_paper': required.update(prefix+n for n in ['source.pdf','pdf_capture.json'])
    if not required <= set(files): errors.append('Freeze omits required benchmark files.')
    for name,digest in files.items():
        target=(base/name).resolve()
        if not target.is_relative_to(base.resolve()):
            errors.append(f'Unsafe freeze path: {name}'); continue
        if not target.is_file() or hashlib.sha256(target.read_bytes()).hexdigest()!=digest:
            errors.append(f'Frozen file changed or missing: {name}')
    return not errors, errors


def check_execution_plan(base, cases):
    """Require a separate concrete run configuration; this never starts inference."""
    path=base/'execution_plan.json'
    if not path.exists(): return False, ['Execution plan is not locked.']
    p=json.loads(path.read_text()); errors=[]
    freeze=base/'freeze_manifest.json'
    expected_hash=hashlib.sha256(freeze.read_bytes()).hexdigest() if freeze.exists() else None
    if p.get('status')!='locked' or p.get('benchmark_freeze_sha256')!=expected_hash:
        errors.append('Execution plan is not locked to this benchmark freeze.')
    digests=p.get('model_digests',{})
    if not isinstance(digests,dict): digests={}
    if set(digests)!={'qwen3:4b','qwen3:8b','gemma3:4b'} or not all(isinstance(v,str) and len(v.removeprefix('sha256:'))==64 and all(c in '0123456789abcdef' for c in v.removeprefix('sha256:')) for v in digests.values()):
        errors.append('All three actual model SHA-256 digests are required.')
    generation=p.get('generation_options',{})
    if not isinstance(generation,dict) or not {'temperature','seed','num_ctx','num_predict'} <= generation.keys():
        errors.append('Generation settings are incomplete.')
    retrieval=p.get('retrieval',{})
    if not isinstance(retrieval,dict) or not {'embedding_model','embedding_revision','chunk_size','chunk_overlap','top_k','context_budget'} <= retrieval.keys():
        errors.append('Retrieval settings are incomplete.')
    for key in ['prompt_sha256','generator_code_sha256']:
        value=p.get(key,'')
        if not isinstance(value,str) or len(value)!=64 or any(c not in '0123456789abcdef' for c in value): errors.append(f'{key} is not pinned.')
    ids=p.get('question_ids',[])
    if not isinstance(ids,list) or not ids or not all(isinstance(i,str) for i in ids) or len(ids)!=len(set(ids)) or not set(ids)<={c['id'] for c in cases}: errors.append('Run question selection is invalid.')
    if p.get('evidence_orders')!=['canonical','reversed']: errors.append('Evidence orders are not locked.')
    budget=p.get('max_generation_calls',0)
    if not isinstance(budget,int) or not isinstance(ids,list) or budget<6*len(ids): errors.append('Explicit generation budget is insufficient.')
    if p.get('verifier_enabled') is not False: errors.append('This baseline requires verifier_enabled=false; later pipelines need a separately reviewed plan.')
    return not errors, errors


def validate(base=BASE):
    errors = []
    def require(condition, message):
        if not condition: errors.append(message)
    def read(name): return json.loads((base / name).read_text(encoding='utf-8'))
    protocol=read('protocol.json'); allocation=read('allocation.json')['slots']
    sources=read('sources.proposed.json')['sources']
    calibration=read('calibration_cases.json')['cases']
    cases=read(protocol.get('case_inventory','calibration_cases.json'))['cases']
    calibration_ids={c['id'] for c in calibration}
    require(protocol['planned_questions']==100, 'Planned question count differs from owner selection.')
    require(len(allocation)==100, 'Allocation must contain 100 slots.')
    require(len({s['slot_id'] for s in allocation})==len(allocation), 'Duplicate allocation slot.')
    require(Counter(s['split'] for s in allocation)=={'development':50,'reserved':50}, 'Split allocation is not 50/50.')
    expected={(split,c['id']):c[split] for split in ['development','reserved'] for c in protocol['categories']}
    require(Counter((s['split'],s['primary_category']) for s in allocation)==expected, 'Skill quotas differ from protocol.')
    require(len(sources)==10 and len({s['id'] for s in sources})==10, 'Expected ten unique sources.')
    byid={s['id']:s for s in sources}; family_splits=defaultdict(set)
    texts={}; extractions={}
    for s in sources:
        family_splits[s['family_id']].add(s['proposed_split'])
        folder=base/'source_snapshots'/s['id']; capture=json.loads((folder/'capture.json').read_text())
        raw=(folder/'raw.html').read_bytes();body=(folder/'body.txt').read_bytes()
        require(hashlib.sha256(raw).hexdigest()==capture['sha256']==s['snapshot_sha256'],f"Raw capture hash mismatch: {s['id']}")
        require(hashlib.sha256(body).hexdigest()==s['text_sha256'],f"Body text hash mismatch: {s['id']}")
        text=body.decode('utf-8');texts[s['id']]=text
        extraction=json.loads((folder/'extraction.json').read_text());extractions[s['id']]=extraction
        require(extraction['text_sha256']==s['text_sha256'],f"Extraction hash mismatch: {s['id']}")
        for block in extraction['segments']:
            require(text[block['start_char']:block['end_char_exclusive']]==block['text'],f"Block offset mismatch: {block['id']}")
        if s['document_type']=='scientific_paper':
            require(s['publication_date'].startswith('2026-'),f"Paper is not a 2026 publication: {s['id']}")
            require(hashlib.sha256((folder/'source.pdf').read_bytes()).hexdigest()==s['pdf_sha256'],f"PDF hash mismatch: {s['id']}")
    require(all(len(v)==1 for v in family_splits.values()),'A document family crosses the split.')
    require(Counter(s['proposed_split'] for s in sources)=={'development':5,'reserved':5},'Source split is not 5/5.')
    require(len(cases)==protocol['authored_questions'], 'Authored count differs from case inventory.')
    require(len({c['id'] for c in cases})==len(cases), 'Duplicate question ID.')
    require(Counter(s['question_id'] for s in allocation if s['question_id'])==Counter(c['id'] for c in cases),'Case/slot mapping differs.')
    case_by_id={c['id']:c for c in cases}
    for slot in allocation:
        if slot['question_id'] in case_by_id:
            case=case_by_id[slot['question_id']]
            require((slot['split'],slot['primary_category'])==(case['split'],case['primary_category']),f"Case assigned to wrong skill/split slot: {case['id']}")
    for c in cases:
        if c['id'] in calibration_ids:
            require(c['split']=='development',f"Calibration case uses reserved split: {c['id']}")
        require(bool(c['question'].strip()) and bool(c['required_response_units']), f"Question/gold units missing: {c['id']}")
        require(c['model_outputs_seen'] is False and c['model_calls']==0,f"Calibration unexpectedly used model output: {c['id']}")
        for sid in c['source_ids']:
            require(byid[sid]['proposed_split']==c['split'],f"Question/source split mismatch: {c['id']}")
            require(byid[sid]['family_id']==c['document_family'],f"Question/family mismatch: {c['id']}")
            require(byid[sid]['text_sha256']==c['source_scope']['text_sha256'],f"Case source scope is stale: {c['id']}")
        if c['answerability']=='unanswerable':
            require(c['source_scope']['full_snapshot_reviewed_for_missing_facts'] or c.get('absence_review',{}).get('status')=='pending_complete_declared_scope_review',f"Untracked complete-scope absence review: {c['id']}")
        for unit in c['required_response_units']:
            require(bool(unit['meaning']),f"Empty unit: {c['id']}/{unit['id']}")
            if unit['response_kind']=='supported_fact':require(bool(unit['evidence_alternatives']),f"No supporting spans: {c['id']}/{unit['id']}")
            for alternative in unit['evidence_alternatives']:
                require(bool(alternative['all_required_spans']),f"Empty evidence set: {c['id']}")
                for span in alternative['all_required_spans']:
                    sid=span['source_id'];text=texts[sid]
                    require(sid in c['source_scope']['allowed_document_ids'],f"Evidence outside scope: {c['id']}")
                    require(span['text_sha256']==byid[sid]['text_sha256'],f"Gold span hash mismatch: {c['id']}")
                    require(0<=span['start_char']<span['end_char_exclusive']<=len(text),f"Gold span out of bounds: {c['id']}")
                    require(text[span['start_char']:span['end_char_exclusive']]==span['exact_text'],f"Gold exact span mismatch: {c['id']}")
        if c.get('calculation'):
            calc=c['calculation']; values=[Decimal(o['value']) for o in calc['operands']]
            op=calc['operation']; result=None
            if op=='subtract' and len(values)==2: result=values[0]-values[1]
            elif op=='add': result=sum(values,Decimal(0))
            elif op=='multiply' and len(values)==2: result=values[0]*values[1]
            elif op=='ceil_divide' and len(values)==2 and values[1]>0: result=(values[0]/values[1]).to_integral_value(rounding=ROUND_CEILING)
            elif op=='ratio_percent' and len(values)==2 and values[1]!=0: result=values[0]/values[1]*100
            elif op=='relative_increase_percent' and len(values)==2 and values[1]!=0: result=(values[0]-values[1])/values[1]*100
            require(result is not None,f"Unsupported calculation operation or inputs: {c['id']}")
            if result is not None:
                require(abs(result-Decimal(calc['expected_value']))<=Decimal(calc.get('tolerance','0')),f"Gold calculation mismatch: {c['id']}")
        if c.get('reasoning_plan'):
            seen_steps=set(); cited_blocks=set()
            source_blocks={b['id'] for sid in c['source_ids'] for b in extractions[sid]['segments']}
            for step in c['reasoning_plan']:
                require(step['id'] not in seen_steps, f"Duplicate reasoning step: {c['id']}/{step['id']}")
                require(bool(step['description'].strip()), f"Empty reasoning step: {c['id']}")
                require(set(step['depends_on']) <= seen_steps, f"Forward or unknown reasoning dependency: {c['id']}/{step['id']}")
                require(bool(step['evidence_block_ids']) and set(step['evidence_block_ids']) <= source_blocks, f"Unknown reasoning evidence block: {c['id']}/{step['id']}")
                seen_steps.add(step['id']); cited_blocks.update(step['evidence_block_ids'])
            if c['primary_category']=='multi_passage':
                require(len(cited_blocks)>=2 and any(s['depends_on'] for s in c['reasoning_plan']), f"Missing multi-passage reasoning structure: {c['id']}")
        elif c['primary_category']=='multi_passage':
            require(False,f"Multi-passage case has no reasoning plan: {c['id']}")
        if c['primary_category']=='arithmetic_units':
            require(bool(c.get('calculation')),f"Arithmetic case has no checkable calculation: {c['id']}")
    require(calibration_ids <= {c['id'] for c in cases},'Original calibration questions missing from full inventory.')
    missing_reviews=[c['id'] for c in cases if c['answerability']=='unanswerable' and not c['source_scope']['full_snapshot_reviewed_for_missing_facts']]
    unaccepted=[c['id'] for c in cases if c['annotation_status']!='accepted_gold']
    source_qa_pending=[sid for sid,e in extractions.items() if e.get('qa_status')!='accepted']
    source_discrepancies=[c['id'] for c in cases if c.get('source_discrepancy',{}).get('status')=='requires_final_adjudication_before_freeze']
    freeze_ok,freeze_errors=check_freeze(base)
    if protocol['status']=='frozen': errors.extend(freeze_errors)
    benchmark_ready=(not errors and len(cases)==100 and protocol['status']=='frozen' and freeze_ok and not unaccepted and not missing_reviews and not source_qa_pending and not source_discrepancies)
    plan_ok,plan_errors=check_execution_plan(base,cases)
    ready=benchmark_ready and plan_ok
    return {'structural_checks_passed':not errors,'ready_for_model_execution':ready,
            'benchmark_ready_for_configuration':benchmark_ready,'freeze_integrity_passed':freeze_ok,
            'execution_plan_blockers':plan_errors,
            'planned_questions':100,'authored_draft_questions':len(cases),'remaining_to_author':100-len(cases),
            'reviewed_gold_questions':len(cases)-len(unaccepted),
            'captured_sources':len(sources),'captured_paper_pdfs':sum(s['document_type']=='scientific_paper' for s in sources),
            'split_slots':dict(Counter(s['split'] for s in allocation)),'errors':errors,
            'gold_acceptance_pending':len(unaccepted),'complete_scope_absence_reviews_pending':missing_reviews,
            'source_qa_pending':source_qa_pending,
            'source_discrepancies_pending':source_discrepancies,
            'limits':'Consistency checks preserve the reviewed source/gold contract; they are not an independent accuracy study or blanket raw-archive redistribution clearance. No model inference is performed.',
            'model_calls':0}


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--require-ready',action='store_true');args=parser.parse_args()
    report=validate();destination=BASE/'validation_report.json';destination.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
    if not report['structural_checks_passed']:raise SystemExit(1)
    if args.require_ready and not report['ready_for_model_execution']:raise SystemExit(2)


if __name__=='__main__':main()
